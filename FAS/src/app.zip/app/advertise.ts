export class Advertise {
    constructor(
    public  adv_id:number,
    public adv_title:string,
    public adv_description:string
 )   {}

}
