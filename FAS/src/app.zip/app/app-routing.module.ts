import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdvertiseListComponent } from './advertise/advertise-list/advertise-list.component';
import { CreateAdvertiseComponent } from './advertise/create-advertise/create-advertise.component';
import { UpdateAdvertiseComponent } from './advertise/update-advertise/update-advertise.component';
import { ComplaintListComponent } from './complaint-list/complaint-list.component';
import { CreateComplaintComponent } from './create-complaint/create-complaint.component';
import { CreateFarmerComponent } from './farmer/create-farmer/create-farmer.component';
import { FarmerListComponent } from './farmer/farmer-list/farmer-list.component';
import { UpdateFarmerComponent } from './farmer/update-farmer/update-farmer.component';
import { UpdateComplaintComponent } from './update-complaint/update-complaint.component';

const routes: Routes = [
  { path: '', redirectTo: 'complaint', pathMatch: 'full' },
  { path: 'add', component: CreateComplaintComponent },
  { path: 'complaints', component: ComplaintListComponent },
  { path: 'update/:id', component: UpdateComplaintComponent },
  { path: 'addF', component: CreateFarmerComponent },
  { path: 'farmers', component: FarmerListComponent },
  { path: 'updates/:idF', component: UpdateFarmerComponent },
  { path: 'addA', component: CreateAdvertiseComponent },
  { path: 'advertises', component: AdvertiseListComponent },
  { path: 'updatead/:id_adv', component: UpdateAdvertiseComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
