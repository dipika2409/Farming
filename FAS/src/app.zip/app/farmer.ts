export class Farmer {
    constructor(
        public farmer_id:number,
        public first_name:string,
        public last_name:string,
        public gender:string,
        public contact_number:string,
        public complaint_id:number,
        
    ){}
}

