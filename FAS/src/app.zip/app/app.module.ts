import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComplaintComponent } from './create-complaint/create-complaint.component';
import { CompserviceService } from './service/compservice.service';
import { ComplaintListComponent } from './complaint-list/complaint-list.component';
import { UpdateComplaintComponent } from './update-complaint/update-complaint.component';
import { CreateFarmerComponent } from './farmer/create-farmer/create-farmer.component';
import { FarmerListComponent } from './farmer/farmer-list/farmer-list.component';
import { UpdateFarmerComponent } from './farmer/update-farmer/update-farmer.component';
import { CreateAdvertiseComponent } from './advertise/create-advertise/create-advertise.component';
import { AdvertiseListComponent } from './advertise/advertise-list/advertise-list.component';
import { UpdateAdvertiseComponent } from './advertise/update-advertise/update-advertise.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatToolbarModule} from '@angular/material/toolbar';

import{ MatFormFieldModule } from '@angular/material/form-field';

import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';





@NgModule({
  declarations: [
    AppComponent,
    CreateComplaintComponent,
    ComplaintListComponent,
    UpdateComplaintComponent,
    CreateFarmerComponent,
    FarmerListComponent,
    UpdateFarmerComponent,
    CreateAdvertiseComponent,
    AdvertiseListComponent,
    UpdateAdvertiseComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatButtonModule,

    MatToolbarModule,

    MatFormFieldModule,

    MatInputModule
  ],
  providers: [CompserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
