import { Farmer } from './farmer';

describe('Farmer', () => {
  it('should create an instance', () => {
    expect(new Farmer()).toBeTruthy();
  });
});
