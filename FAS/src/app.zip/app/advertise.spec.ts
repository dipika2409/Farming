import { Advertise } from './advertise';

describe('Advertise', () => {
  it('should create an instance', () => {
    expect(new Advertise()).toBeTruthy();
  });
});
